/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.workplicity.cia;

import javax.swing.ImageIcon;
import org.workplicity.cia.ui.MainFrame;
import org.workplicity.cia.worklet.ElogsWorklet;
import org.workplicity.plugin.util.Host;
import org.workplicity.task.NetTask;
import org.workplicity.util.Helper;
import org.workplicity.util.Logger;
import org.workplicity.util.Resources;
import org.workplicity.worklet.WorkletContext;

/**
 * Class for launching the worklet in debug mode.
 * @author Ron Coleman
 */
public class Main {
    private static void launchForDebug(String logn, String passwd, String url, Integer svcId) {
        // Set the url to access the server
        NetTask.setUrlBase(url);

        NetTask.setStoreName("nl");

        // Get a context a populate it with the svc id and host info, if we needed it
        WorkletContext context = WorkletContext.getInstance();

        context.setSvcId(svcId);

        context.publish(Resources.TAG_HOST, new Host(url));

        // Login
        if (!Helper.login("admin", "gaze11e", context)) {
            return;
        }

        // Now that the login has suceeded, the context is now
        // ready as if we came through the JNLP, so let's
        // finish the job and (literally) go that route by invoking
        // "go" on the context
        Resources.logoSmall = new ImageIcon("/logo3.png");

        ElogsWorklet worklet = new ElogsWorklet();

        worklet.go(context);
    }


    private static void launchForJNLP() {
        try {
            javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                final MainFrame frame = new MainFrame();

                frame.setLocationByPlatform(true);

                frame.addWindowListener(new java.awt.event.WindowAdapter() {

                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        frame.winClose();

                        System.exit(0);
                    }
                });

                frame.setVisible(true);
            }
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(final String args[]) {
        Logger.setEnabled(false);

        if (args != null) {
            String logn = args[0];

            String passw = args[1];

            String url = args[2];

            Integer svcId = Integer.parseInt(args[3]);

            launchForDebug(logn, passw, url, svcId);
        } else {
            launchForJNLP();
        }
    }
}
