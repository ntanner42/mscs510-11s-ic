//Copyright (C) 2011 Ron Coleman. Contact: ronncoleman@gmail.com
//
//This library is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 3 of the License, or (at your option) any later version.
//
//This library is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this library; if not, write to the Free Software
//Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

package org.workplicity.cia.table;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import javax.swing.table.AbstractTableModel;
import org.workplicity.cia.util.CIAHelper;
import org.workplicity.entry.Comment;
import org.workplicity.util.DateFormatter;

/**
 This class implements the comments table model.
 * @author Ron Coleman
 */
public class CommentsTableModel extends AbstractTableModel {
    private String[] columnNames = {"Date",
                                    "User",
                                    "Comment"};

    private ArrayList<Comment> comments = new ArrayList<Comment>( );

    /**
     * Constructor
     */
    public CommentsTableModel() {

    }

    /**
     * Gets the comments.
     * @return Comments
     */
    public ArrayList<Comment> getComments() {
        return comments;
    }

    /**
     * Sets the comments, replaces the old ones.
     * @param comments
     */
    public void setComments(ArrayList<Comment> comments) {
        this.comments = comments;
    }

    /**
     * Gets the number of comments.
     * @return Count
     */
    public int getRowCount() {
        return comments.size();
    }

    /**
     * Gets the number of columns.
     * @return Count
     */
    public int getColumnCount() {
        return columnNames.length;
    }

    /**
     * Gets the column name.
     * @param col
     * @return Name
     */
    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    /**
     * Gets a value in the table.
     * @param row Row
     * @param col Column
     * @return Value
     */
    public Object getValueAt(int row, int col) {
        Comment comment = comments.get(row);

        if(col == 0)
            return DateFormatter.toString(comment.getDate());

        else if(col == 1)
            return CIAHelper.toUser(comment.getUserId());

        else
            return CIAHelper.asOneLine(comment.getText());
    }

    /**
     * Gets a row
     * @param row Row
     * @return Comment
     */
    public Comment getRow(int row) {
        if(row < 0 || row >= comments.size())
            return null;

        return comments.get(row);
    }

    /**
     * Refreshes the comments
     */
    public void refresh() {
        Collections.sort(comments, new Comparator() {
            public int compare(Object o1, Object o2) {
                Date d1 = ((Comment) o1).getDate();
                Date d2 = ((Comment) o2).getDate();
                return d2.compareTo(d1);
            }
        });

        fireTableDataChanged();
    }
}
