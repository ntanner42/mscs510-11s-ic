//Copyright (C) 2010 Ron Coleman. Contact: ronncoleman@gmail.com
//
//This library is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 3 of the License, or (at your option) any later version.
//
//This library is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this library; if not, write to the Free Software
//Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

package org.workplicity.cia.table;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import org.workplicity.cia.worklet.ElogsWorklet;
import org.workplicity.elog.entry.Trade;
import org.workplicity.elog.repos.Trades;
import org.workplicity.util.Helper;
import org.workplicity.worklet.WorkletContext;

/**
 * This class implements the trades table model.
 * @author Ron Coleman
 */
public class TradesTableModel extends AbstractTableModel {
    /**
     * Column names
     */
    private String[] columnNames = {
        "Id",
        "Name",
        "Description",
    };

    /**
     * Container of trades
     */
    private ArrayList<Trade> trades = new ArrayList<Trade>( );

    /**
     * Constructor
     */
    public TradesTableModel()
    {
    }

    /**
     * Gets the name for a column.
     * @param col Column number.
     * @return Column name
     */
    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }
    
    /**
     * Gets a trade field.
     * @param row Table row
     * @param col Table column
     * @returnvalue
     */
    public Object getValueAt(int row, int col)
    {
        if(row >= trades.size())
            return null;

        Trade trade = trades.get(row);

        if(col == 0)
            return trade.getId();

        if(col == 1)
            return trade.getName();

        if(col == 2)
            return trade.getDescription();

        return null;
    }

    /**
     * Gets the row count.
     * @return count
     */
    public int getRowCount()
    {
        return trades.size();
    }

    /**
     * Gets the column count.
     * @return Count
     */
    public int getColumnCount()
    {
        return columnNames.length;
    }

    /**
     * Gets row.
     * @param row Row
     * @return row
     */
    public Trade getRow(int row)
    {
        if(row >= trades.size())
            return null;

        return trades.get(row);
    }

    /**
     * Refreshes the trades model
     */
    public void refresh()
    {
        WorkletContext context = ElogsWorklet.getInstance().getContext();

        trades = Helper.query(Trades.TITLE,"/list", context);

        this.fireTableDataChanged();
    }
}
