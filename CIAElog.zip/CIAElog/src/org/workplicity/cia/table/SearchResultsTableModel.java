/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.workplicity.cia.table;

import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.table.AbstractTableModel;
import org.workplicity.cia.worklet.ElogsWorklet;
import org.workplicity.elog.entry.Elog;
import org.workplicity.task.NetTask;
import org.workplicity.util.Helper;
import org.workplicity.worklet.WorkletContext;
import org.workplicity.entry.User;

/**
 * @author Game Slave 2
 */

public class SearchResultsTableModel extends AbstractTableModel {

    private ArrayList<Elog> results = new ArrayList<Elog>( );
    private HashMap<Integer,Elog> dirty = new HashMap<Integer,Elog>( );

    private ElogsWorklet worklet = ElogsWorklet.getInstance();
    private WorkletContext context = worklet.getContext();

    private static String[] columnNames = {
        "Id",
        "Updated",
        "User",
        "Type",
        "Status"
    };

    public int getRowCount() {
        return results.size();
    }

    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int col){
        return columnNames[col];
    }

    @Override
    public boolean isCellEditable(int row, int col){
        return false;
    }

    public Object getValueAt(int row, int col) {
        //throw new UnsupportedOperationException("Not supported yet.");
        Elog result = results.get(row);

        // id column
        if(col == 0){
            String indicator = "";
            String wsId = result.getRequestId();

            if(dirty.get(Integer.parseInt(wsId)) != null){
                indicator = "*";
            }

            return wsId + indicator;
        }

        // Updated column
        if(col == 1)
            return result.getUpdateDate();

        // User column
        if(col == 2){
            int userId = result.getCreateUserId();
            String criteria = "/list[id="+userId+"]";
            ArrayList<User> users = Helper.query(NetTask.REPOS_ACCOUNTS, criteria, context);
            return users.get(0).getLogname();
        }

        // Type column
        if(col == 3)
            return result.getType();

        // Status column
        if(col == 4)
            return result.getStatus();

        // non-existant column
        return "";
    }
}