//Copyright (C) 2009 Ron Coleman. Contact: ronncoleman@gmail.com
//
//This library is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 3 of the License, or (at your option) any later version.
//
//This library is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this library; if not, write to the Free Software
//Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

package org.workplicity.cia.table;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import javax.swing.table.AbstractTableModel;
import org.workplicity.cia.util.CIAHelper;
import org.workplicity.cia.worklet.ElogsWorklet;
import org.workplicity.elog.entry.Elog;
import org.workplicity.elog.entry.Elog.Status;
import org.workplicity.elog.entry.Elog.Type;
import org.workplicity.elog.entry.ElogUser;
import org.workplicity.elog.entry.ElogUser.Function;
import org.workplicity.util.DateFormatter;
import org.workplicity.util.Helper;
import org.workplicity.worklet.WorkletContext;

/**
 * This class is the model for the elogs table.
 * @author Ron Coleman
 */
public class ElogsTableModel extends AbstractTableModel {
    /**
     * Names of the columns
     */
    private String[] columnNames = {
        "Id",
        "Updated",
        "By",
        "Type",
        "Status",
        "Description"};

    /**
     * Elogs that are rendered in the table
     */
    private ArrayList<Elog> elogs = new ArrayList<Elog>( );

    /**
     * Elog type: NORMAL vs. UNUSUAL
     */
    private Type type;

    /**
     * User requesting this table which may be expanded
     * if the user is not a WORKER
     */
    private ElogUser user;

    /**
     * Status: DONE vs. NOTDONE
     */
    private Status status;

    /**
     * Function
     */
    private Function function;

    private long end;

    private long start;

    public int getRowCount() {
        return elogs.size();
    }

    public int getColumnCount() {
        return columnNames.length;
    }

    public Object getValueAt(int row, int col) {
        if(row >= elogs.size())
            return null;

        Elog elog = elogs.get(row);

        if(col == 0)
            return elog.getId();

        if(col == 1)
            return DateFormatter.toString(elog.getUpdateDate());

        // TODO: This will probably need to be last update user
        if(col == 2)
            return CIAHelper.toUser(elog.getUpdateUserId());

        if(col == 3)
            return elog.getType();

        if(col == 4)
            return elog.getStatus();

        if(col == 5)
            return CIAHelper.asOneLine(elog.getDescription());

        return null;
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    /**
     * Gets an elog by row.
     * @param row Row
     * @return Elog
     */
    public Elog getRow(int row) {
        if(row >= elogs.size())
            return null;

        return elogs.get(row);
    }

    /**
     * Refreshes the table of elogs;
     */
    public void refresh(ElogUser user) {
        this.user = user;

        String criteria = "/ list [ id = " + user.getElogsId() + " ] / list ";

        String criteria2 = "/ list [ title = '" + user.getReposTitle()+"' ] / list [ ";
        criteria2 += "updateDate > " + start + " and updateDate <= " + end;

        HashSet<ElogUser> subs = new HashSet<ElogUser>();
        
        subs.add(user);

        CIAHelper.gatherSubordinates(user, subs);

        String titles = "";

        for(ElogUser sub : subs) {
            if(titles.length() != 0)
                titles += " or ";
            titles += "title = '" + sub.getReposTitle() + "'";
        }

        String criteria3 = "/ list [ " + titles + " ] / list [ ";
        criteria3 += "updateDate > " + start + " and updateDate <= " + end;

        if(status != Elog.Status.ANY)
            criteria3 += " and status = '" + status +"'";

        if(type != Elog.Type.ANY)
            criteria3 += " and type = '" + type + "'";
        
        criteria3 += " ] ";

        WorkletContext context = ElogsWorklet.getInstance().getContext();

        elogs = Helper.query(criteria3, context);

        Collections.sort(elogs, new Comparator() {
            public int compare(Object o1, Object o2) {
                Date d1 = ((Elog) o1).getUpdateDate();
                Date d2 = ((Elog) o2).getUpdateDate();
                return d2.compareTo(d1);
            }
        });

        this.fireTableDataChanged();
    }

    /**
     * Sets the start period.
     * @param start Start time
     */
    public void setStart(long start) {
        this.start = start;
    }

    /**
     * Sets the end period.
     * @param end End time
     */
    public void setEnd(long end) {
        this.end = end;
    }

    /**
     * Sets the view.
     * @param function
     */
    public void setView(ElogUser.Function function) {
        this.function = function;
    }

    /**
     * Sets the type.
     * @param type Type
     */
    public void setType(Elog.Type type) {
        this.type = type;
    }

    /**
     * Sets the status
     * @param status Status
     */
    public void setStatus(Elog.Status status) {
        this.status = status;
    }
}
