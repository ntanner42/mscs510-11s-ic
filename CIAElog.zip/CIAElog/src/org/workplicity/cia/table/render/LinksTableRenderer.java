/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.workplicity.cia.table.render;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import org.workplicity.cia.table.LinksTableModel;
import org.workplicity.cia.util.CIAHelper;
import org.workplicity.elog.entry.Elog;

/**
 *
 * @author Ron Coleman
 */
public class LinksTableRenderer extends BaseTableRenderer /*DefaultTableCellRenderer*/ {

    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected,
            boolean isFocused, int row, int col) {
        if (col == 0) {
            boolean marked = (Boolean) value;
            JCheckBox rendererComponent = new JCheckBox();
            if (marked) {
                rendererComponent.setSelected(true);
            }
            return rendererComponent;
        }
        else {
            LinksTableModel model = (LinksTableModel) table.getModel();

            Elog elog = model.getRow(row);
            if (isSelected) {
                setBackground(BaseTableRenderer.bgSelectedColor);
            } else if (CIAHelper.isRecent(elog)) {
                setBackground(BaseTableRenderer.bgFreshColor);
            } else {
                setBackground(Color.white);
            }

            setForeground(Color.black);
        }

        return this;
    }
}
