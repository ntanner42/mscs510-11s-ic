//Copyright (C) 2011 Ron Coleman. Contact: ronncoleman@gmail.com
//
//This library is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 3 of the License, or (at your option) any later version.
//
//This library is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this library; if not, write to the Free Software
//Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

package org.workplicity.cia.table.render;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import org.workplicity.cia.table.HandoffsTableModel;
import org.workplicity.cia.util.CIAHelper;
import org.workplicity.elog.entry.Handoff;
import org.workplicity.entry.User;
import org.workplicity.util.Helper;
import org.workplicity.worklet.WorkletContext;

/**
 * This class implements the table renderer for the handoffs table.
 * @author Ron Coleman
 */
public class HandoffsTableRenderer extends BaseTableRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        HandoffsTableModel model = (HandoffsTableModel) table.getModel();

        Handoff handoff = model.getRow(row);

        if(isSelected)
            setBackground(bgSelectedColor);
        else if(CIAHelper.isRecent(handoff))
            setBackground(bgFreshColor);
        else
            setBackground(Color.white);

        setForeground(Color.black);

        return this;
    }
}
