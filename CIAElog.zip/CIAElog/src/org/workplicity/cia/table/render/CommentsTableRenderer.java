/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.workplicity.cia.table.render;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import org.workplicity.cia.table.CommentsTableModel;
import org.workplicity.cia.util.CIAHelper;
import org.workplicity.entry.Comment;
import org.workplicity.entry.User;
import org.workplicity.util.Helper;
import org.workplicity.worklet.WorkletContext;

/**
 * This class implements a custom renderer for the comments table.
 * @author Ron Coleman
 */
public class CommentsTableRenderer extends BaseTableRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        CommentsTableModel model = (CommentsTableModel) table.getModel();

        Comment comment = model.getRow(row);

        User me = Helper.whoAmI(WorkletContext.getInstance());

        if(isSelected)
            setBackground(bgSelectedColor);
        else if(CIAHelper.isRecent(comment.getDate()))
            setBackground(bgFreshColor);
        else
            setBackground(Color.white);

        setForeground(Color.black);

        return this;
    }
}
