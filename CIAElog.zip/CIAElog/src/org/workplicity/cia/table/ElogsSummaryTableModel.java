//Copyright (C) 2010 Ron Coleman. Contact: ronncoleman@gmail.com
//
//This library is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 3 of the License, or (at your option) any later version.
//
//This library is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this library; if not, write to the Free Software
//Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

package org.workplicity.cia.table;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import javax.swing.table.AbstractTableModel;
import org.workplicity.cia.util.CIAHelper;
import org.workplicity.elog.entry.Elog;
import org.workplicity.util.DateFormatter;
import org.workplicity.util.Helper;
import org.workplicity.worklet.WorkletContext;

/**
 * This class implements the elogs summary table model for linking
 * log entries.
 * @author Ron Coleman
 */
public class ElogsSummaryTableModel extends AbstractTableModel {
    /**
     * Column names
     */
    private String[] columnNames = {
        "Id",
        "Update",
        "Type",
        "Description",
    };

    private ArrayList<Elog> elogs = new ArrayList<Elog>( );

    private String reposName;

    private long end;

    private long start;

    /**
     * Gets the row count.
     * @return Count
     */
    public int getRowCount() {
        return elogs.size();
    }

    /**
     * Gets the column count.
     * @return Count
     */
    public int getColumnCount() {
        return columnNames.length;
    }

    /**
     * Gets the name for a column.
     * @param col Column number.
     * @return Column name
     */
    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    /**
     * Gets the value at row x col in the table.
     * @param row Row
     * @param col Col
     * @return Cell
     */
    public Object getValueAt(int row, int col) {
        if(row < 0 || row >= elogs.size())
            return null;

        Elog elog = elogs.get(row);

        if(col == 0)
            return elog.getId();

        if(col == 1)
            return DateFormatter.toString(elog.getUpdateDate());

        if(col == 2)
            return elog.getType();

        if(col == 3)
            return CIAHelper.asOneLine(elog.getDescription());

        return null;
    }

    /**
     * Gets the table row.
     * @param row Row
     * @return Elog
     */
    public Elog getRow(int row) {
        if(row < 0 || row >= elogs.size())
            return null;

        return elogs.get(row);
    }

    public void refresh() {
        String criteria =
                "/ list [ updateDate >= " + start +" and updateDate < " + end + " ]";

//        String criteria =
//                "/ list [ updateDate < " + end + " ]";

        elogs = Helper.query(reposName,criteria,WorkletContext.getInstance());

        Collections.sort(elogs, new Comparator() {
            public int compare(Object o1, Object o2) {
                Date d1 = ((Elog) o1).getUpdateDate();
                Date d2 = ((Elog) o2).getUpdateDate();
                return d2.compareTo(d1);
            }
        });

        this.fireTableDataChanged();
    }

    /**
     * Sets the age end period.
     * @param end End time
     */
    public void setEnd(long end) {
        this.end = end;
    }

    /**
     * Sets the age start period.
     * @param start Start time
     */
    public void setStart(long start) {
        this.start = start;
    }

    /**
     * Sets the repository name
     * @param reposName Repository name
     */
    public void setReposName(String reposName) {
        this.reposName = reposName;
    }

}
