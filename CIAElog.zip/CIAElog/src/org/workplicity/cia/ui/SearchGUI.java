/*
 * To change this template, ch

            public void setSelectedItem(Object anItem) {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public Object getSelectedItem() {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public int getSize() {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public Object getElementAt(int index) {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public void addListDataListener(ListDataListener l) {
                throw new UnsupportedOperationException("Not supported yet.");
            }

            public void removeListDataListener(ListDataListener l) {
                throw new UnsupportedOperationException("Not supported yet.");
            }
        }ose Tools | Templates
 * and open the template in the editor.
 */

/*
 * SearchGUI.java
 *
 * Created on Feb 24, 2011, 1:20:04 PM
 */


package org.workplicity.cia.ui;

//import java.util.ArrayList;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.ArrayList;
import java.util.Date;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import org.workplicity.cia.worklet.ElogsWorklet;
import org.workplicity.elog.entry.ElogUser;
import org.workplicity.entry.User;
import org.workplicity.task.NetTask;
import org.workplicity.util.Helper;
import org.workplicity.worklet.WorkletContext;

/**
 *
 * @author Adam and Mike
 */
public class SearchGUI extends javax.swing.JFrame {
    private ElogUser user = null;

    private ElogsWorklet worklet = ElogsWorklet.getInstance();

    private WorkletContext context = worklet.getContext();

    /** Creates new form SearchGUI */
    public SearchGUI() {
        initComponents();
        this.setLocationRelativeTo(null);

        this.setSize(330, 410);

        user = (ElogUser) Helper.whoAmI(context);
        this.setTitle("Netlog (" + user.getLogname() + ") >> Search");

        populateUserCombo();

        Calendar cal = Calendar.getInstance();

        // Sets default start date to today's date
        Date startDate = cal.getTime();
        String dateStringStart = "";
        dateStringStart = dateFormat.format(startDate);
        startTimeTextField.setText(dateStringStart);
        startCalendarButton.setTargetDate(startDate);

        // Sets default end date to yesterday's date
        cal.add(Calendar.DAY_OF_YEAR, -1);
        Date endDate = cal.getTime();
        String dateStringEnd = "";
        dateStringEnd = dateFormat.format(endDate);
        endTimeTextField.setText(dateStringEnd);
        endCalendarButton.setTargetDate(endDate);

        searchByIdTextField.addFocusListener(new FocusListener() {
            //This makes the default text disappear for the field on the first click
            boolean focusedOnce = false;
            @Override
            public void focusGained(FocusEvent e) {
                if (!focusedOnce) {
                    searchByIdTextField.setText("");
                    focusedOnce = true;
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
            }
        });

        keywordTextField.addFocusListener(new FocusListener() {
            //This makes the default text disappear for the field on the first click
            boolean focusedOnce = false;
            @Override
            public void focusGained(FocusEvent e) {
                if (!focusedOnce) {
                    keywordTextField.setText("");
                    focusedOnce = true;
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
            }
        });
    }

    /**
     * Query Accounts Repository to get Users, sort names in alphabetical order
     * and add them to the User ComboBox drop down.
     */
    private void populateUserCombo() {
         // query
         String criteria = "/list";
         ArrayList<User> users = Helper.query(NetTask.REPOS_ACCOUNTS, criteria, context);

         // get names from User objects
         String[] userArray = new String[users.size()];
         int index = 0;
         for(User currentUser : users){
             userArray[index++] = currentUser.getLogname();
         }

         // sort alphabetically
         Arrays.sort(userArray);

         // add user names to combo box
         for(String userName : userArray){
            userComboBox.addItem(userName);
         }

         // select default value
         this.userComboBox.setSelectedItem("All");
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        jFrame1 = new javax.swing.JFrame();
        jFrame2 = new javax.swing.JFrame();
        goButton = new javax.swing.JButton();
        findWholeWordsOnlyCheckBox = new javax.swing.JCheckBox();
        cancelButton = new javax.swing.JButton();
        typeComboBox = new javax.swing.JComboBox();
        typeLabel = new javax.swing.JLabel();
        keywordTextField = new javax.swing.JTextField();
        keywordLabel = new javax.swing.JLabel();
        searchByIdTextField = new javax.swing.JTextField();
        matchCaseCheckBox = new javax.swing.JCheckBox();
        searchHandoffsCheckBox = new javax.swing.JCheckBox();
        searchByIdCheckBox = new javax.swing.JCheckBox();
        endTimeLabel = new javax.swing.JLabel();
        userComboBox = new javax.swing.JComboBox();
        endTimeTextField = new javax.swing.JTextField();
        searchByIdLabel = new javax.swing.JLabel();
        startTimeLabel = new javax.swing.JLabel();
        startTimeTextField = new javax.swing.JTextField();
        startCalendarButton = new net.sourceforge.jcalendarbutton.JCalendarButton();
        endCalendarButton = new net.sourceforge.jcalendarbutton.JCalendarButton();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame2Layout.setVerticalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setAlwaysOnTop(true);
        setResizable(false);

        goButton.setFont(new java.awt.Font("Tahoma", 0, 12));
        goButton.setText("Go");
        goButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goButtonActionPerformed(evt);
            }
        });

        findWholeWordsOnlyCheckBox.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        findWholeWordsOnlyCheckBox.setText("Find whole words only");

        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, searchByIdCheckBox, org.jdesktop.beansbinding.ELProperty.create("${!selected}"), findWholeWordsOnlyCheckBox, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        cancelButton.setFont(new java.awt.Font("Tahoma", 0, 12));
        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        typeComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "---Select---", "URGENT", "NORMAL" }));
        typeComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                typeComboBoxActionPerformed(evt);
            }
        });

        typeLabel.setFont(new java.awt.Font("Tahoma", 0, 12));
        typeLabel.setText(" Type: ");

        keywordTextField.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        keywordTextField.setText("Enter text");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, searchByIdCheckBox, org.jdesktop.beansbinding.ELProperty.create("${!selected}"), keywordTextField, org.jdesktop.beansbinding.BeanProperty.create("editable"));
        bindingGroup.addBinding(binding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, searchByIdCheckBox, org.jdesktop.beansbinding.ELProperty.create("${!selected}"), keywordTextField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        keywordLabel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        keywordLabel.setText("Keyword: ");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, searchByIdCheckBox, org.jdesktop.beansbinding.ELProperty.create("${!selected}"), keywordLabel, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        searchByIdTextField.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        searchByIdTextField.setText("Enter a number");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, searchByIdCheckBox, org.jdesktop.beansbinding.ELProperty.create("${selected}"), searchByIdTextField, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        matchCaseCheckBox.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        matchCaseCheckBox.setText("Match case");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, searchByIdCheckBox, org.jdesktop.beansbinding.ELProperty.create("${!selected}"), matchCaseCheckBox, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        searchHandoffsCheckBox.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        searchHandoffsCheckBox.setText("Search handoffs");

        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, searchByIdCheckBox, org.jdesktop.beansbinding.ELProperty.create("${!selected}"), searchHandoffsCheckBox, org.jdesktop.beansbinding.BeanProperty.create("enabled"));
        bindingGroup.addBinding(binding);

        searchByIdCheckBox.setText("Search by id:");
        searchByIdCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchByIdCheckBoxActionPerformed(evt);
            }
        });

        endTimeLabel.setFont(new java.awt.Font("Tahoma", 0, 12));
        endTimeLabel.setText("End: ");

        userComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "All" }));

        endTimeTextField.setFont(new java.awt.Font("Tahoma", 0, 12));

        searchByIdLabel.setFont(new java.awt.Font("Tahoma", 0, 12));
        searchByIdLabel.setText("User: ");

        startTimeLabel.setFont(new java.awt.Font("Tahoma", 0, 12));
        startTimeLabel.setText(" Start: ");

        startTimeTextField.setFont(new java.awt.Font("Tahoma", 0, 12));

        startCalendarButton.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                startCalendarButtonFocusLost(evt);
            }
        });
        startCalendarButton.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                startCalendarButtonPropertyChange(evt);
            }
        });

        endCalendarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                endCalendarButtonActionPerformed(evt);
            }
        });
        endCalendarButton.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                endCalendarButtonFocusLost(evt);
            }
        });
        endCalendarButton.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                endCalendarButtonPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(keywordLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(searchByIdCheckBox)
                                    .addComponent(searchByIdLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(typeLabel)
                                    .addComponent(endTimeLabel)
                                    .addComponent(startTimeLabel))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(searchByIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(userComboBox, 0, 210, Short.MAX_VALUE)
                                    .addComponent(keywordTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(typeComboBox, 0, 210, Short.MAX_VALUE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(endTimeTextField)
                                            .addComponent(startTimeTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(endCalendarButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(startCalendarButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addComponent(searchHandoffsCheckBox, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(matchCaseCheckBox, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(findWholeWordsOnlyCheckBox, javax.swing.GroupLayout.Alignment.LEADING))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(goButton, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchByIdLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchByIdCheckBox)
                    .addComponent(searchByIdTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(keywordLabel)
                    .addComponent(keywordTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(typeLabel)
                    .addComponent(typeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(startTimeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(startTimeLabel))
                    .addComponent(startCalendarButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(endTimeLabel)
                    .addComponent(endTimeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(endCalendarButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(searchHandoffsCheckBox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(matchCaseCheckBox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(findWholeWordsOnlyCheckBox)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelButton)
                    .addComponent(goButton, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40))
        );

        bindingGroup.bind();
    }// </editor-fold>//GEN-END:initComponents

    private void searchByIdCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchByIdCheckBoxActionPerformed
        // TODO add your handling code here:
}//GEN-LAST:event_searchByIdCheckBoxActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        // TODO add your handling code here:
        dispose();
}//GEN-LAST:event_cancelButtonActionPerformed

    private void typeComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_typeComboBoxActionPerformed
        // TODO add your handling code here:
}//GEN-LAST:event_typeComboBoxActionPerformed

    private void goButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goButtonActionPerformed
        // TODO add your handling code here:

        //If search by id is checked, and it does not validate, give an error,
        //and terminate the search
        if (searchByIdCheckBox.isSelected()) {
            try {
                int idToValidate = Integer.parseInt(searchByIdTextField.getText());
                if (idToValidate < 1) {
                    throw new NumberFormatException();
                }

            }
            catch (NumberFormatException ex) {
                String message = "Id number must be a valid positive integer.";
                JOptionPane.showMessageDialog(new JFrame(), message, "Error",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        //Otherwise the search by keyword is enabled and must be checked
        //if blank throw an exception
        else
            try{
                 String keyword = keywordTextField.getText();
                 if(keyword.equals("")){
                    throw new Exception();
                 }
            }
            catch (Exception keyword){
                String message = "Keyword field can not be blank.";
                JOptionPane.showMessageDialog(new JFrame(), message, "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }


        final JFrame table = this;
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                
                final SearchTableResults dialog = new SearchTableResults(table);
                
                dialog.setVisible(true);
            }
        });
    }//GEN-LAST:event_goButtonActionPerformed

    private void startCalendarButtonPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_startCalendarButtonPropertyChange
        if (evt.getNewValue() instanceof Date)
            setStartDate((Date)evt.getNewValue());
    }//GEN-LAST:event_startCalendarButtonPropertyChange

    private void endCalendarButtonPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_endCalendarButtonPropertyChange
       if (evt.getNewValue() instanceof Date)
            setEndDate((Date)evt.getNewValue());
    }//GEN-LAST:event_endCalendarButtonPropertyChange

    private void startCalendarButtonFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_startCalendarButtonFocusLost
        String date = startTimeTextField.getText();
        setStartDate(date);
    }//GEN-LAST:event_startCalendarButtonFocusLost

    private void endCalendarButtonFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_endCalendarButtonFocusLost
        String date = endTimeTextField.getText();
        setEndDate(date);
    }//GEN-LAST:event_endCalendarButtonFocusLost

    private void endCalendarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_endCalendarButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_endCalendarButtonActionPerformed
     public static void main(String args[]){
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e){

                }

            final SearchGUI search = new SearchGUI();
            search.setSize(330, 410);

            search.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent e) {

                    System.exit(0);

                }
            });

            search.setVisible(true);
        }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelButton;
    private net.sourceforge.jcalendarbutton.JCalendarButton endCalendarButton;
    private javax.swing.JLabel endTimeLabel;
    private javax.swing.JTextField endTimeTextField;
    private javax.swing.JCheckBox findWholeWordsOnlyCheckBox;
    private javax.swing.JButton goButton;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JLabel keywordLabel;
    private javax.swing.JTextField keywordTextField;
    private javax.swing.JCheckBox matchCaseCheckBox;
    private javax.swing.JCheckBox searchByIdCheckBox;
    private javax.swing.JLabel searchByIdLabel;
    public javax.swing.JTextField searchByIdTextField;
    private javax.swing.JCheckBox searchHandoffsCheckBox;
    private net.sourceforge.jcalendarbutton.JCalendarButton startCalendarButton;
    private javax.swing.JLabel startTimeLabel;
    private javax.swing.JTextField startTimeTextField;
    private javax.swing.JComboBox typeComboBox;
    private javax.swing.JLabel typeLabel;
    private javax.swing.JComboBox userComboBox;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables

public static DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);

public void setStartDate(String dateString)
    {
		Date date = null;
		try	{
            if ((dateString != null) && (dateString.length() > 0))
                date = dateFormat.parse(dateString);
		} catch (Exception e)	{
            date = null;
		}
        this.setStartDate(date);
    }
    /**
     * Validate and set the datetime field on the screen given a startDate.
     * @param dateTime The datetime object
     */
    public void setStartDate(Date date)
    {
        String dateString = "";
        if (date != null)
    		dateString = dateFormat.format(date);
        startTimeTextField.setText(dateString);
        startCalendarButton.setTargetDate(date);
    }

         /**
     * Validate and set the datetime field on the screen given a datetime string.
     * @param dateTime The datetime string
     */
    public void setEndDate(String dateString)
    {
		Date date = null;
		try	{
            if ((dateString != null) && (dateString.length() > 0))
                date = dateFormat.parse(dateString);
		} catch (Exception e)	{
            date = null;
		}
        this.setEndDate(date);
    }
    /**
     * Validate and set the datetime field on the screen given a startDate.
     * @param dateTime The datetime object
     */
    public void setEndDate(Date date)
    {
        String dateString = "";
        if (date != null)
    		dateString = dateFormat.format(date);
        endTimeTextField.setText(dateString);
        endCalendarButton.setTargetDate(date);
    }

}

